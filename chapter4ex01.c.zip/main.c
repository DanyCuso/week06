#include <stdio.h>

int main(void) {
  
  char firstname[20], lastname[20];
    int bir_year;
    int sec_num;
    printf("Escribe tu Nombre: ");
    scanf("%s", firstname);
    printf("Escribe tus apellidos: ");
    scanf("%s", lastname);
    printf("escribe tu nuemero de seguridad: ");
    scanf("%i", &sec_num);
    printf("Input your year of birth: ");
    scanf("%i", &bir_year);
    printf(" %s\n %s\n %d\n %d\n", firstname, lastname, sec_num, bir_year);

  
  return 0;
}