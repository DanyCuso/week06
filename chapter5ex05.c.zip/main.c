#include <stdio.h>

int main(void) {

int hour, minute, second, timeinmin;

printf("Enter the value for hour: ");
scanf("%d", &hour);
printf("Enter the value for minute: ");
scanf("%d", &minute);

timeinmin = (minute * 60) + (hour * 60 * 60);

printf("Total minutes in %d:%d=%d\n", hour, minute, timeinmin);

return 0;
}
