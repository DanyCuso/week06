#include <stdio.h>

int main(void) {

int alto;
int ancho;
int perimeter;

printf("escriba el alto del rectangulo: ");
scanf("%i", &alto);
printf("escriba el ancho del rectangulo: ");
scanf("%i", &ancho);

perimeter = 2*(ancho + alto);

printf("el perimetro es: %i", perimeter);

return 0;
}
