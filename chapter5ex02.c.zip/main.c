#include <stdio.h>

int main(void) {

float radio;
float volume;
float pi;

pi = 3.14159265359;

printf("introdusca el radio de la esfera: ");
scanf("%f", &radio);

volume = (4*(pi)*(radio)*(radio)*(radio))/3;

printf("el volumen de la esfera es: %f", volume);

return 0;
}
