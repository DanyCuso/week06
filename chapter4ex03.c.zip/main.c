#include <stdio.h>
#include <stdlib.h>

int main(void) {

float width;          
float height;         
float area;           
float perimeter; 

/*para calcualar el area de cualquier rectangulo, ingrese los datos de altura y anchura de dicho rectangulo en pulgadas*/

printf("ancho del rectangulo: ");
scanf("%f", &width);
printf("altura del rectangulo: ");
scanf("%f", &height);

perimeter = 2*(height + width);
printf("Perimeter of the rectangle = %f inches\n", perimeter);
	
area = height * width;
printf("Area of the rectangle = %f square inches\n", area);

return 0;
}
