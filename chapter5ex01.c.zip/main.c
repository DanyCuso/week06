#include <stdio.h>

int main(void) {

int grad_cen;
int grad_far;

printf("introdusca un grado centigrado: ");
scanf("%d", &grad_cen);

grad_far = (9*(grad_cen)/5)+32;

printf("los grados fahrenheit son: %d F°", grad_far);

return 0;
}
