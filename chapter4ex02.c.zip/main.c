#include <stdio.h>
#include <stdlib.h>

int main(void) {
  int i;
  
for(i=0;i<10;i++)
  printf("*");

for(i=0;i<5;i++)
  printf("*\n");

for(i=0;i<10;i++)
  printf("*");

for(i=0;i<5;i++)
  printf("*\n");

for(i=0;i<10;i++)
  printf("*");
return 0;
}
