#include <stdio.h>

int main(void) {

float km;
float mill;

printf("escriba los kilometros que ha viajado: ");
scanf("%f", &km);

mill = km*0.6213712;

printf("usted ha viajado %f millas", mill);

return 0;
}
