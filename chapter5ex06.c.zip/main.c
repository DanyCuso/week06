#include <stdio.h>

int main(void) {

int totalmin;
int hour;
int min;


printf("escriba el total de minutos a calcular: ");
scanf("%d", &totalmin);

hour = totalmin/60;
min = totalmin % 60;

printf("%d:%d", hour, min);

return 0;
}
